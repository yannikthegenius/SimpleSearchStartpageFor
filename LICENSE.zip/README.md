This extension will add a context menu entry to search for selected text using Google™. Useful for when your default search engine is an alternative like DuckDuckGo™ but you still want to be able to easily search with Google™.

Chrome extension icon made by [Those Icons](https://www.flaticon.com/authors/those-icons) from [www.flaticon.com](https://www.flaticon.com/)

Firefox extension icon made by [Freepik](https://www.freepik.com/) from Flaticon is licensed by [CC 3.0 BY](http://creativecommons.org/licenses/by/3.0/)

* [Privacy Information](https://raw.githubusercontent.com/Aaron-P/SimpleSearchGoogleFor/master/PRIVACY)
